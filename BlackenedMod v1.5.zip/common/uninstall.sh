#!/system/bin/sh
ui_print "We're sorry to see you go..."
rm -r /data/adb/service.d/03KingKernel.sh
rm -r /data/adb/service.d/02BlackenedMod.sh
rm -r /data/adb/service.d/Zipalign_sqlite.sh
ui_print " "

