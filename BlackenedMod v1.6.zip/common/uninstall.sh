#!/system/bin/sh
ui_print "We're sorry to see you go..."
rm -r /sbin/.magisk/img/BlackenedMod/03KingKernel.sh
rm -r /sbin/.magisk/img/BlackenedMod/02BlackenedMod.sh
rm -r /sbin/.magisk/img/BlackenedMod/Zipalign_sqlite.sh
ui_print " "

